import pandas as pd
import numpy as np

np.random.seed(42)

products = {
    "P001": "Bread", "P002": "Butter", "P003": "Milk", "P004": "Eggs",
    "P005": "Cheese", "P006": "Yogurt", "P007": "Apples", "P008": "Bananas",
    "P009": "Chicken", "P010": "Rice", "P011": "Pasta", "P012": "Tomato Sauce",
    "P013": "Coffee", "P014": "Tea", "P015": "Sugar", "P016": "Juice",
    "P017": "Chips", "P018": "Chocolate", "P019": "Detergent", "P020": "Shampoo"
}

categories = {
    "P001": "Bakery", "P002": "Dairy", "P003": "Dairy", "P004": "Dairy",
    "P005": "Dairy", "P006": "Dairy", "P007": "Fruits", "P008": "Fruits",
    "P009": "Meat", "P010": "Grains", "P011": "Grains", "P012": "Condiments",
    "P013": "Beverages", "P014": "Beverages", "P015": "Condiments", "P016": "Beverages",
    "P017": "Snacks", "P018": "Snacks", "P019": "Household", "P020": "Household"
}

# Define basket patterns (frequent combos)
patterns = [
    ["P001", "P002", "P003"],   # Bread + Butter + Milk
    ["P003", "P004", "P001"],   # Milk + Eggs + Bread
    ["P011", "P012", "P005"],   # Pasta + Tomato Sauce + Cheese
    ["P009", "P010", "P012"],   # Chicken + Rice + Tomato Sauce
    ["P013", "P015", "P003"],   # Coffee + Sugar + Milk
    ["P014", "P015"],           # Tea + Sugar
    ["P007", "P008", "P016"],   # Apples + Bananas + Juice
    ["P017", "P018", "P016"],   # Chips + Chocolate + Juice
    ["P019", "P020"],           # Detergent + Shampoo
    ["P004", "P002", "P001"],   # Eggs + Butter + Bread
]

rows = []
transaction_id = 1

for _ in range(500):
    # Pick 1-3 patterns and merge
    n_patterns = np.random.randint(1, 3)
    chosen = np.random.choice(len(patterns), n_patterns, replace=False)
    basket = list(set(sum([patterns[i] for i in chosen], [])))
    # Add 0-2 random products
    extras = np.random.choice(list(products.keys()), np.random.randint(0, 3), replace=False)
    basket = list(set(basket + list(extras)))
    for pid in basket:
        rows.append({
            "Transaction_ID": f"T{transaction_id:04d}",
            "Product_ID": pid,
            "Product_Name": products[pid],
            "Product_Category": categories[pid],
            "Quantity": np.random.randint(1, 5)
        })
    transaction_id += 1

df = pd.DataFrame(rows)
df.to_csv("data.csv", index=False)
print(f"Dataset created: {len(df)} rows, {df['Transaction_ID'].nunique()} transactions")
