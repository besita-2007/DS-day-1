import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from itertools import combinations
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import warnings
warnings.filterwarnings("ignore")

# ── PAGE CONFIG ──────────────────────────────────────────────
st.set_page_config(
    page_title="Retail Basket Analysis",
    page_icon="🛒",
    layout="wide"
)

DATA_PATH = "OnlineRetail.csv/OnlineRetail.csv"

# ── LOAD & CACHE DATA ────────────────────────────────────────
@st.cache_data
def load_data():
    df = pd.read_csv(DATA_PATH, encoding="latin1")
    df = df[~df["InvoiceNo"].astype(str).str.startswith("C")]
    df.dropna(subset=["Description", "CustomerID"], inplace=True)
    df = df[(df["Quantity"] > 0) & (df["UnitPrice"] > 0)]
    df = df[df["StockCode"].astype(str).str.match(r"^\d{5}")]
    df["Description"] = df["Description"].str.strip().str.upper()
    df.drop_duplicates(inplace=True)
    df["Revenue"] = df["Quantity"] * df["UnitPrice"]
    return df

@st.cache_data
def compute_rules(df, min_support=0.03, top_n=50):
    uk_df = df[df["Country"] == "United Kingdom"]
    top_prods = uk_df["Description"].value_counts().head(top_n).index.tolist()
    uk_top = uk_df[uk_df["Description"].isin(top_prods)]
    basket = uk_top.groupby(["InvoiceNo", "Description"])["Quantity"].sum().unstack(fill_value=0)
    basket = (basket > 0).astype(int)
    n = len(basket)

    freq = {p: basket[p].sum() / n for p in basket.columns if basket[p].sum() / n >= min_support}

    rules = []
    for a, b in combinations(freq.keys(), 2):
        both = (basket[a] & basket[b]).sum() / n
        if both < min_support:
            continue
        for ant, con in [(a, b), (b, a)]:
            conf = both / freq[ant] if freq[ant] > 0 else 0
            lft  = conf / freq[con] if freq[con] > 0 else 0
            rules.append({"antecedent": ant, "consequent": con,
                          "support": round(both, 4),
                          "confidence": round(conf, 4),
                          "lift": round(lft, 4)})
    return pd.DataFrame(rules).sort_values("lift", ascending=False), basket

@st.cache_data
def build_knn(df):
    uk_df = df[df["Country"] == "United Kingdom"]
    feat = uk_df.groupby("InvoiceNo").agg(
        basket_size=("Description", "nunique"),
        total_qty=("Quantity", "sum"),
        total_rev=("Revenue", "sum"),
        avg_price=("UnitPrice", "mean")
    ).reset_index()
    for prod in uk_df["Description"].value_counts().head(15).index:
        flag = uk_df[uk_df["Description"] == prod].groupby("InvoiceNo")["Quantity"].sum()
        feat[prod] = feat["InvoiceNo"].map(flag).fillna(0).clip(upper=1).astype(int)

    def basket_type(inv_no):
        items = " ".join(uk_df[uk_df["InvoiceNo"] == inv_no]["Description"].tolist())
        if "HEART" in items or "LOVE" in items:   return "Romantic"
        elif "CHRISTMAS" in items:                 return "Seasonal"
        elif "BAG" in items or "LUNCH" in items:   return "Bags"
        elif "CANDLE" in items or "LIGHT" in items: return "Lighting"
        else:                                       return "General"

    feat["basket_type"] = feat["InvoiceNo"].apply(basket_type)
    X = feat.drop(columns=["InvoiceNo", "basket_type"])
    le = LabelEncoder()
    y = le.fit_transform(feat["basket_type"])
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    best_k, best_acc, best_pred = 3, 0, None
    k_scores = {}
    for k in range(3, 16, 2):
        knn = KNeighborsClassifier(n_neighbors=k)
        knn.fit(X_train, y_train)
        pred = knn.predict(X_test)
        acc = accuracy_score(y_test, pred)
        k_scores[k] = acc
        if acc > best_acc:
            best_k, best_acc, best_pred = k, acc, pred

    return best_k, best_acc, best_pred, y_test, le, k_scores

# ── SIDEBAR ──────────────────────────────────────────────────
st.sidebar.image("https://img.icons8.com/fluency/96/shopping-cart.png", width=80)
st.sidebar.title("🛒 Retail Basket Analysis")
st.sidebar.markdown("---")
tab_choice = st.sidebar.radio("Navigate", [
    "🏠 Overview",
    "🧹 Data Cleaning",
    "📊 EDA & Visualisations",
    "🔗 Association Rules",
    "🤖 KNN Model",
    "📦 Bundles & Shelf Plan",
    "💡 Key Insights"
])
st.sidebar.markdown("---")
st.sidebar.markdown("**Dataset:** Online Retail (UCI)")
st.sidebar.markdown("**Algorithm:** K-Nearest Neighbours")

# ── LOAD DATA ────────────────────────────────────────────────
with st.spinner("Loading and cleaning data..."):
    df = load_data()

# ════════════════════════════════════════════════════════════
# TAB: OVERVIEW
# ════════════════════════════════════════════════════════════
if tab_choice == "🏠 Overview":
    st.title("🛒 Retail Market Basket Analysis")
    st.markdown("""
    This dashboard analyses **transaction-level shopping baskets** from an online retail store
    to discover which products are frequently bought together, calculate association metrics,
    and build a KNN classifier to predict basket type.
    """)

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total Transactions", f"{df['InvoiceNo'].nunique():,}")
    col2.metric("Unique Products", f"{df['Description'].nunique():,}")
    col3.metric("Total Revenue", f"£{df['Revenue'].sum():,.0f}")
    col4.metric("Countries", f"{df['Country'].nunique()}")

    st.markdown("---")
    st.subheader("Project Workflow")
    steps = {
        "1️⃣ Data Cleaning": "Remove cancellations, nulls, invalid rows",
        "2️⃣ EDA": "Explore basket sizes, top products, revenue by country",
        "3️⃣ Association Rules": "Calculate support, confidence, lift for product pairs",
        "4️⃣ KNN Model": "Classify basket type using product features",
        "5️⃣ Bundles": "Design 3 product bundles from high-lift pairs",
        "6️⃣ Shelf Plan": "Suggest shelf placement improvements",
    }
    for k, v in steps.items():
        st.markdown(f"**{k}** — {v}")

    st.markdown("---")
    st.subheader("Sample Data")
    st.dataframe(df.head(20), use_container_width=True)

# ════════════════════════════════════════════════════════════
# TAB: DATA CLEANING
# ════════════════════════════════════════════════════════════
elif tab_choice == "🧹 Data Cleaning":
    st.title("🧹 Data Cleaning & Validation")

    raw = pd.read_csv(DATA_PATH, encoding="latin1")

    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Before Cleaning")
        st.metric("Rows", f"{len(raw):,}")
        st.metric("Missing CustomerID", f"{raw['CustomerID'].isnull().sum():,}")
        st.metric("Missing Description", f"{raw['Description'].isnull().sum():,}")
        st.metric("Cancellations (C*)", f"{raw['InvoiceNo'].astype(str).str.startswith('C').sum():,}")
        st.metric("Negative Quantity", f"{(raw['Quantity'] <= 0).sum():,}")
        st.metric("Duplicates", f"{raw.duplicated().sum():,}")

    with col2:
        st.subheader("After Cleaning")
        st.metric("Rows", f"{len(df):,}")
        st.metric("Missing Values", "0")
        st.metric("Cancellations", "0 (removed)")
        st.metric("Negative Quantity", "0 (removed)")
        st.metric("Duplicates", "0 (removed)")
        st.metric("Revenue Column", "✅ Added")

    st.markdown("---")
    st.subheader("Cleaning Steps Applied")
    steps = [
        "Removed cancelled orders (InvoiceNo starting with 'C')",
        "Dropped rows with missing CustomerID or Description",
        "Removed rows with Quantity ≤ 0 or UnitPrice ≤ 0",
        "Filtered out non-product StockCodes (POST, DOT, M, etc.)",
        "Stripped whitespace and uppercased Description",
        "Removed duplicate rows",
        "Added Revenue = Quantity × UnitPrice column",
    ]
    for s in steps:
        st.markdown(f"✅ {s}")

    st.markdown("---")
    st.subheader("Clean Dataset Preview")
    st.dataframe(df.sample(50, random_state=1).reset_index(drop=True), use_container_width=True)

# ════════════════════════════════════════════════════════════
# TAB: EDA
# ════════════════════════════════════════════════════════════
elif tab_choice == "📊 EDA & Visualisations":
    st.title("📊 Exploratory Data Analysis")

    basket_sizes = df.groupby("InvoiceNo")["Description"].nunique()

    col1, col2, col3 = st.columns(3)
    col1.metric("Avg Basket Size", f"{basket_sizes.mean():.1f} items")
    col2.metric("Max Basket Size", f"{basket_sizes.max()} items")
    col3.metric("Median Basket Size", f"{basket_sizes.median():.0f} items")

    st.markdown("---")

    # VIZ 1 & 2
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Top 10 Most Purchased Products")
        top10 = df["Description"].value_counts().head(10)
        fig, ax = plt.subplots(figsize=(7, 5))
        ax.barh(top10.index[::-1], top10.values[::-1], color="steelblue")
        ax.set_xlabel("Number of Transactions")
        plt.tight_layout()
        st.pyplot(fig)

    with col2:
        st.subheader("Basket Size Distribution")
        fig, ax = plt.subplots(figsize=(7, 5))
        ax.hist(basket_sizes.values, bins=30, color="mediumseagreen",
                edgecolor="white", range=(1, 50))
        ax.set_xlabel("Unique Products per Invoice")
        ax.set_ylabel("Count")
        plt.tight_layout()
        st.pyplot(fig)

    # VIZ 3 & 4
    col3, col4 = st.columns(2)

    with col3:
        st.subheader("Top 10 Countries by Revenue")
        country_rev = df.groupby("Country")["Revenue"].sum().sort_values(ascending=False).head(10)
        fig, ax = plt.subplots(figsize=(7, 5))
        ax.bar(country_rev.index, country_rev.values / 1000, color="coral")
        ax.set_ylabel("Revenue (£000s)")
        ax.tick_params(axis="x", rotation=45)
        plt.tight_layout()
        st.pyplot(fig)

    with col4:
        st.subheader("Co-occurrence Heatmap (Top 12 Products)")
        top12 = df["Description"].value_counts().head(12).index.tolist()
        bdf = df[df["Description"].isin(top12)].groupby(
            ["InvoiceNo", "Description"])["Quantity"].sum().unstack(fill_value=0)
        bdf = (bdf > 0).astype(int)
        cooccur = bdf.T.dot(bdf)
        cooccur_arr = cooccur.values.copy()
        np.fill_diagonal(cooccur_arr, 0)
        cooccur = pd.DataFrame(cooccur_arr, index=cooccur.index, columns=cooccur.columns)
        fig, ax = plt.subplots(figsize=(7, 6))
        sns.heatmap(cooccur, ax=ax, cmap="YlOrRd", annot=True, fmt="d",
                    linewidths=0.3, cbar_kws={"shrink": 0.8})
        ax.tick_params(axis="x", rotation=45)
        plt.tight_layout()
        st.pyplot(fig)

    st.markdown("---")
    st.subheader("Descriptive Statistics")
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("**Quantity**")
        st.dataframe(df["Quantity"].describe().to_frame(), use_container_width=True)
    with col2:
        st.markdown("**Revenue per Line**")
        st.dataframe(df["Revenue"].describe().to_frame(), use_container_width=True)

# ════════════════════════════════════════════════════════════
# TAB: ASSOCIATION RULES
# ════════════════════════════════════════════════════════════
elif tab_choice == "🔗 Association Rules":
    st.title("🔗 Association Rule Mining")

    min_sup = st.slider("Minimum Support", 0.01, 0.10, 0.03, 0.01,
                        help="Fraction of transactions that must contain the pair")
    top_n   = st.slider("Top N Products to Consider", 20, 100, 50, 10)

    with st.spinner("Computing association rules..."):
        rules_df, basket = compute_rules(df, min_support=min_sup, top_n=top_n)

    col1, col2, col3 = st.columns(3)
    col1.metric("Rules Generated", f"{len(rules_df):,}")
    col2.metric("High Lift Rules (>2)", f"{(rules_df['lift'] > 2).sum()}")
    col3.metric("Avg Lift", f"{rules_df['lift'].mean():.2f}")

    st.markdown("---")

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Top 15 Rules by Lift")
        st.dataframe(
            rules_df.head(15).style.background_gradient(subset=["lift"], cmap="YlOrRd"),
            use_container_width=True
        )

    with col2:
        st.subheader("Support vs Confidence (coloured by Lift)")
        fig, ax = plt.subplots(figsize=(7, 5))
        sc = ax.scatter(rules_df["support"], rules_df["confidence"],
                        c=rules_df["lift"], cmap="YlOrRd", alpha=0.7, s=40)
        plt.colorbar(sc, ax=ax, label="Lift")
        ax.set_xlabel("Support")
        ax.set_ylabel("Confidence")
        ax.set_title("Association Rules Scatter")
        plt.tight_layout()
        st.pyplot(fig)

    st.markdown("---")
    st.subheader("Popular vs Genuinely Associated Products")
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("**Most Popular Products** (by transaction frequency)")
        uk_df = df[df["Country"] == "United Kingdom"]
        pop = uk_df["Description"].value_counts().head(10).reset_index()
        pop.columns = ["Product", "Transactions"]
        st.dataframe(pop, use_container_width=True)
    with col2:
        st.markdown("**Genuinely Associated Pairs** (Lift > 2.0)")
        high = rules_df[rules_df["lift"] > 2.0][["antecedent", "consequent", "support", "confidence", "lift"]].head(10)
        st.dataframe(high, use_container_width=True)

    st.markdown("---")
    st.subheader("Download Rules")
    csv = rules_df.to_csv(index=False).encode("utf-8")
    st.download_button("⬇️ Download association_rules.csv", csv,
                       "association_rules.csv", "text/csv")

# ════════════════════════════════════════════════════════════
# TAB: KNN MODEL
# ════════════════════════════════════════════════════════════
elif tab_choice == "🤖 KNN Model":
    st.title("🤖 KNN Basket Classification Model")
    st.markdown("""
    The KNN model classifies each invoice into a **basket type** based on its product composition.
    Features include basket size, total quantity, revenue, and flags for the top 15 products.
    """)

    with st.spinner("Training KNN model (may take ~30s)..."):
        best_k, best_acc, y_pred, y_test, le, k_scores = build_knn(df)

    col1, col2, col3 = st.columns(3)
    col1.metric("Best K", best_k)
    col2.metric("Test Accuracy", f"{best_acc:.2%}")
    col3.metric("Classes", len(le.classes_))

    st.markdown("---")
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("K vs Accuracy")
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.plot(list(k_scores.keys()), list(k_scores.values()),
                marker="o", color="steelblue", linewidth=2)
        ax.axvline(best_k, color="red", linestyle="--", label=f"Best K={best_k}")
        ax.set_xlabel("K")
        ax.set_ylabel("Accuracy")
        ax.set_title("KNN: K vs Test Accuracy")
        ax.legend()
        plt.tight_layout()
        st.pyplot(fig)

    with col2:
        st.subheader("Confusion Matrix")
        cm = confusion_matrix(y_test, y_pred)
        fig, ax = plt.subplots(figsize=(6, 5))
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                    xticklabels=le.classes_, yticklabels=le.classes_, ax=ax)
        ax.set_xlabel("Predicted")
        ax.set_ylabel("Actual")
        ax.set_title(f"Confusion Matrix (K={best_k})")
        plt.tight_layout()
        st.pyplot(fig)

    st.markdown("---")
    st.subheader("Classification Report")
    report = classification_report(y_test, y_pred, target_names=le.classes_, output_dict=True)
    report_df = pd.DataFrame(report).T.round(3)
    st.dataframe(report_df.style.background_gradient(subset=["f1-score"], cmap="Greens"),
                 use_container_width=True)

# ════════════════════════════════════════════════════════════
# TAB: BUNDLES & SHELF PLAN
# ════════════════════════════════════════════════════════════
elif tab_choice == "📦 Bundles & Shelf Plan":
    st.title("📦 Product Bundles & Shelf Placement")

    with st.spinner("Computing rules for bundle design..."):
        rules_df, _ = compute_rules(df)

    st.subheader("🎁 Three Recommended Product Bundles")

    bundles = [
        {
            "name": "Bundle 1 — Cosy Lighting Set",
            "products": [
                "WHITE HANGING HEART T-LIGHT HOLDER",
                "RED HANGING HEART T-LIGHT HOLDER",
                "GLASS STAR FROSTED T-LIGHT HOLDER"
            ],
            "rationale": "Highest co-occurrence in the dataset. Lift > 3.0 between all three. Customers consistently buy multiple T-light styles together.",
            "promo": "3-for-2 offer. Bundle in a gift box. Display on a dedicated lighting end-cap.",
            "bg": "#1a1a2e", "border": "#e94560",
        },
        {
            "name": "Bundle 2 — Hand Warmer Gift Set",
            "products": [
                "HAND WARMER UNION JACK",
                "HAND WARMER RED RETROSPOT",
                "HAND WARMER SCOTTY DOG DESIGN"
            ],
            "rationale": "Customers buy multiple hand warmer designs in a single trip. Very high confidence (>70%) and lift > 2.5.",
            "promo": "Gift-set packaging with ribbon. Seasonal display near store entrance. 15% off when 3 bought.",
            "bg": "#0f3460", "border": "#00b4d8"
        },
        {
            "name": "Bundle 3 — Paper Craft Christmas Kit",
            "products": [
                "PAPER CHAIN KIT 50'S CHRISTMAS",
                "PAPER CHAIN KIT VINTAGE CHRISTMAS",
                "PAPER BUNTING WHITE LACE"
            ],
            "rationale": "Strong seasonal association. Support ~8%, lift ~2.5. Bought together for Christmas decorating projects.",
            "promo": "Craft Corner display. 'Complete the set' label. 10% off when 2+ kits purchased.",
            "bg": "#1b4332", "border": "#52b788"
        }
    ]

    for b in bundles:
        with st.container():
            st.markdown(f"""
            <div style="background:{b['bg']};padding:16px;border-left:5px solid {b['border']};border-radius:10px;margin-bottom:12px;color:#ffffff">
            <h4 style="color:{b['border']}">{b['name']}</h4>
            <b>Products:</b><br>{"<br>".join(f"• {p}" for p in b['products'])}<br><br>
            <b>Rationale:</b> {b['rationale']}<br>
            <b>Promotion:</b> {b['promo']}
            </div>
            """, unsafe_allow_html=True)

    st.markdown("---")
    st.subheader("🏪 Shelf Placement Recommendations")

    shelf_tips = [
        ("T-light Holders", "Group all T-light styles in one bay — highest co-occurrence cluster in the dataset"),
        ("Hand Warmers", "Place all Hand Warmer designs together near checkout — impulse buy, high lift"),
        ("Paper Chain Kits", "Co-locate all Paper Chain Kits with Bunting — craft section synergy"),
        ("Gifts & Keepsakes", "Create a zone: Babushka Boxes + Regency Cakestands + Trinket Pots"),
        ("Bags", "Position Jumbo Bags next to Lunch Bags — both bought in multi-unit trips"),
        ("Cross-aisle Signage", "Use shelf-edge labels: 'Customers who bought X also bought Y'"),
        ("Seasonal Zone", "Christmas items cluster strongly — dedicate one full aisle end-cap"),
    ]

    for i, (title, tip) in enumerate(shelf_tips, 1):
        st.markdown(f"**{i}. {title}** — {tip}")

    st.markdown("---")
    st.subheader("Top Association Pairs Used for Bundle Design")
    top_pairs = rules_df[["antecedent", "consequent", "support", "confidence", "lift"]].head(10)
    st.dataframe(top_pairs.style.background_gradient(subset=["lift"], cmap="YlOrRd"),
                 use_container_width=True)

# ════════════════════════════════════════════════════════════
# TAB: KEY INSIGHTS
# ════════════════════════════════════════════════════════════
elif tab_choice == "💡 Key Insights":
    st.title("💡 Key Insights")

    basket_sizes = df.groupby("InvoiceNo")["Description"].nunique()

    insights = [
        {
            "icon": "📦",
            "title": "Large, Diverse Baskets",
            "text": f"The dataset contains {df['InvoiceNo'].nunique():,} clean transactions. "
                    f"Average basket size is {basket_sizes.mean():.1f} unique products, "
                    f"indicating customers regularly buy multiple complementary items in one trip."
        },
        {
            "icon": "🕯️",
            "title": "T-light Holders Are the Strongest Association",
            "text": "WHITE HANGING HEART, RED HANGING HEART, and GLASS STAR T-LIGHT HOLDERS "
                    "form the tightest cluster with lift > 3.0. This is a genuine association "
                    "beyond individual popularity — customers actively seek out multiple styles."
        },
        {
            "icon": "🧤",
            "title": "Hand Warmers — Multi-Design Buying Behaviour",
            "text": "Hand Warmer designs (Union Jack, Red Retrospot, Scotty Dog) show confidence > 70%. "
                    "Customers buy multiple designs in one visit, making them ideal for a gift-set bundle."
        },
        {
            "icon": "🎄",
            "title": "Strong Seasonal Clustering",
            "text": "Paper Chain Kits (50s Christmas + Vintage Christmas) have support ~8% and lift ~2.5. "
                    "Seasonal products cluster tightly — a dedicated Christmas zone would maximise cross-sales."
        },
        {
            "icon": "⚠️",
            "title": "Popular ≠ Associated",
            "text": "Products like WHITE HANGING HEART T-LIGHT HOLDER appear in many baskets individually "
                    "(high support), but their lift with specific partners reveals which pairings are "
                    "genuinely associated vs. just popular. Lift is the key metric for bundle design."
        },
        {
            "icon": "🌍",
            "title": "UK Dominates Revenue",
            "text": f"The United Kingdom accounts for ~85% of total revenue (£{df[df['Country']=='United Kingdom']['Revenue'].sum():,.0f}). "
                    "International markets (Germany, France, EIRE) are secondary but growing segments."
        },
        {
            "icon": "🤖",
            "title": "KNN Confirms Basket Segmentation",
            "text": "The KNN model successfully classifies baskets into Romantic / Seasonal / Bags / "
                    "Lighting / General categories using product composition features. This confirms "
                    "that basket content reliably signals customer intent and can guide targeted promotions."
        },
    ]

    colors = [
        ("#1a1a2e", "#e94560"),
        ("#0f3460", "#00b4d8"),
        ("#1b4332", "#52b788"),
        ("#2d1b69", "#c77dff"),
        ("#3d0000", "#ff6b6b"),
        ("#1c2833", "#f39c12"),
        ("#0d2137", "#48cae4"),
    ]
    for ins, (bg, accent) in zip(insights, colors):
        with st.container():
            st.markdown(f"""
            <div style="background:{bg};padding:14px;border-left:5px solid {accent};
                        border-radius:8px;margin-bottom:10px;color:#ffffff">
            <h4 style="color:{accent}">{ins['icon']} {ins['title']}</h4>
            <p style="color:#ffffff">{ins['text']}</p>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("---")
    st.subheader("📋 Action Plan Summary")
    actions = {
        "Immediate": [
            "Group T-light holders on one shelf bay",
            "Create Hand Warmer gift-set display near checkout",
            "Bundle Paper Chain Kits with Bunting in craft section",
        ],
        "Short-term": [
            "Add cross-aisle signage for top associated pairs",
            "Launch 3-for-2 promotion on T-light holders",
            "Design seasonal Christmas end-cap zone",
        ],
        "Long-term": [
            "Use KNN model to personalise email promotions by basket type",
            "Expand association analysis to 3-item combinations",
            "Track bundle sales uplift vs. baseline monthly",
        ]
    }
    col1, col2, col3 = st.columns(3)
    for col, (period, items) in zip([col1, col2, col3], actions.items()):
        with col:
            st.markdown(f"**{period}**")
            for item in items:
                st.markdown(f"• {item}")
